<?php
session_start();


$host="localhost";
$dbuser="root";
$dbpass="";
$db="test1";
$conn = new mysqli($host,$dbuser,$dbpass,$db);

mysqli_select_db($conn,$db);





$name = $_POST['name'];
$gender=$_POST['gender']; 
$phone_number = $_POST['phone_number'];
$blood_group=$_POST['blood_group'];
$age=$_POST['age'];
$address=$_POST['address'];
$smoke=$_POST['smoke'];
$alcohol=$_POST['alcohol'];
$drugs=$_POST['drugs'];
$disease=$_POST['disease'];
$input_email=$_POST['input_email'];
$input_password=$_POST['input_password'];
$confirm_password=$_POST['confirm_password'];
//$btnsubmit=$_POST['btnsubmit'];

//echo $smoke;

                       

$s="select * from donor_detail where email = '$input_email'";            
$result=mysqli_query($conn,$s);
$num=mysqli_num_rows($result);
if($num == 1){
	
        echo " EMAIL ALREADY IN USE";
}
else{
	$reg="INSERT INTO donor_detail (name, gender, phone, bloodgrp, age, address, smoke, alcohol, drugs, disease, email, password) VALUES ('$name','$gender','$phone_number','$blood_group','$age','$address','$smoke','$alcohol','$drugs','$disease','$input_email','$input_password')"; 
	mysqli_query($conn,$reg);
	echo "registration successful";
	header("location:http://localhost/iwt/donor_camps_display.html");
	//echo "Error: " . mysqli_error($conn);  // Print the MySQL error
}

