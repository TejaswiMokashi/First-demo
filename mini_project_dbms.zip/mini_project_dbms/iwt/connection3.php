<?php
session_start();


$host="localhost";
$dbuser="root";
$dbpass="";
$db="test1";
$conn = new mysqli($host,$dbuser,$dbpass,$db);

mysqli_select_db($conn,$db);
 


//$name = $_POST['name'];
//$gender=$_POST['gender']; 
//$phone_number = $_POST['phone_number'];
///$blood_group=$_POST['blood_group'];
//$age=$_POST['age'];
//$address=$_POST['address'];
//$Date=$_POST['Date'];
$input_email=$_POST['input_email'];
$password=$_POST['password'];
//$confirm_password=$_POST['confirm_password'];
//$btnsubmit=$_POST['btnsubmit'];
//$btnlogin=$_POST['btnlogin'];

$s=" select * from receiver_detail where email = '$input_email' && password = '$password' ";
$result=mysqli_query($conn,$s);
$num=mysqli_num_rows($result);
if($num == 1){
	header("location:http://localhost/iwt/blood_banks_display.html");
}


else{
	echo " EMAIL OR  PASSWORD  ENTERED  IS  WRONG";
	
}
?>