<?php
session_start();


$host="localhost";
$dbuser="root";
$dbpass="";
$db="test1";
$conn = new mysqli($host,$dbuser,$dbpass,$db);

mysqli_select_db($conn,$db);
 


$name = $_POST['name'];
$gender=$_POST['gender']; 
$phone_number = $_POST['phone_number'];
$blood_group=$_POST['blood_group'];
$age=$_POST['age'];
$address=$_POST['address'];
//$Date=$_POST['Date'];
$input_email=$_POST['input_email'];
$input_password=$_POST['input_password'];
$confirm_password=$_POST['confirm_password'];
$btnsubmit=$_POST['btnsubmit'];
//$btnlogin=$_POST['btnlogin'];

$s=" select * from receiver_detail where email = '$input_email'";
$result=mysqli_query($conn,$s);
$num=mysqli_num_rows($result);
if($num == 1){
        echo " EMAIL ALREADY IN USE";
}


else{
	$reg="insert into receiver_detail(name,gender,phone,bloodgrp,age,address,email,password)values('$name','$gender','$phone_number','$blood_group','$age','$address','$input_email','$input_password')";
	
	mysqli_query($conn,$reg);
	echo"registration successful";
	header("location:http://localhost/iwt/reciever_login_page.html");
}
?>




